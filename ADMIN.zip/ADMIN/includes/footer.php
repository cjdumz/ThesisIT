        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Copyright © 2018, Abenchers | Design: IT Project 2
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>